The following WFS-1.1 test data are available for GMLSF levels 0, 1 and 2.
Loading these features into the datastore is a precondition for compliance
testing (see Note below).

sf-0/
  dataset-sf0-insert.xml    - test data for SF-0 (WFS Transaction)*

sf-1/
  dataset-sf1-insert.xml    - additional test data for SF-1 (WFS Transaction)*

sf-2/
  dataset-sf2-insert.xml    - additional test data for SF-2 (WFS Transaction)*

* NOTE: The Transaction request entities are provided as a convenience, but no
assumptions are made about how the test data are loaded into the implementation
under test.
