The following WFS-1.1.0 test data are available for GMLSF levels 0 and 1.
Loading these features into the datastore is a precondition for compliance 
testing.

sf-0/
  dataset-sf0.xml            - test data for SF-0 (GML3)
  dataset-sf0.pgdump         - PostgreSQL/PostGIS dump file
  dataset-sf0_postgis.sql    - PostgreSQL/PostGIS SQL script
  dataset-sf0_oracle.sql     - Oracle SQL script

sf-1/
  dataset-sf1.xml            - additional test data for SF-1 (GML3)


NOTE
---- 
GMLSF Levels 0 and 1 DO NOT support the use of feature collections through 
WFS interfaces. The collections defined here are provided for convenience 
only--they are not themselves GML features.